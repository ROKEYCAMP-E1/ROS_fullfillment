import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image  # /image_raw 토픽 메시지 타입
from cv_bridge import CvBridge  # ROS 이미지 메시지를 OpenCV 이미지로 변환
import cv2  # OpenCV 라이브러리
from ultralytics import YOLO  # YOLOv8 라이브러리

class ImageSubscriber(Node):
    def __init__(self):
        super().__init__('image_subscriber')  # 노드 이름 설정
        self.subscription = self.create_subscription(
            Image,  # 메시지 타입
            '/image_raw',  # 토픽 이름
            self.listener_callback,  # 콜백 함수
            10  # QoS 설정 (큐 사이즈)
        )
        self.subscription  # prevent unused variable warning
        self.bridge = CvBridge()  # CvBridge 인스턴스 생성
        self.model = YOLO('cat_box.pt')  # YOLOv8 모델 로드 (사전 훈련된 모델 사용)

    def listener_callback(self, msg):
        # ROS Image 메시지를 OpenCV 이미지로 변환
        cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

        # YOLOv8 모델로 객체 탐지 수행
        results = self.model(cv_image)

        # 탐지된 이미지가 있을 경우
        if len(results[0].boxes) > 0:
            # 바운딩 박스를 그린 이미지를 얻음
            frame_with_boxes = results[0].plot()

            # 이미지 크기 정보 확인
            image_height, image_width, _ = frame_with_boxes.shape

            # 화면 중앙 x 좌표 계산
            center_x = image_width // 2
            center_y = image_height // 2
            
            # 중앙 좌표에서 일정 거리 떨어진 세로줄 추가
            cv2.line(frame_with_boxes, (center_x - 100, center_y - 20), (center_x - 100, center_y + 240), (0, 255, 255), 2)  # 왼쪽 줄 (노란색)
            cv2.line(frame_with_boxes, (center_x + 80, center_y - 20), (center_x + 80, center_y + 240), (0, 255, 255), 2)  # 오른쪽 줄 (노란색)
    
            cv2.line(frame_with_boxes, (center_x - 60, center_y + 40), (center_x - 60, center_y + 210), (0, 255, 0), 2)  # 왼쪽 줄 (초록색)
            cv2.line(frame_with_boxes, (center_x + 40, center_y + 40), (center_x + 40, center_y + 210), (0, 255, 0), 2)  # 오른쪽 줄 (초록색)

            cv2.line(frame_with_boxes, (center_x - 100, center_y - 20), (center_x + 80, center_y - 20), (0, 255, 255), 2)  # 위 가로줄 (노란색)
            cv2.line(frame_with_boxes, (center_x - 100, center_y + 240), (center_x + 80, center_y + 240), (0, 255, 255), 2)  # 아래 가로줄 (노란색)

            cv2.line(frame_with_boxes, (center_x - 60, center_y + 40), (center_x + 40, center_y + 40), (0, 255, 0), 2)  # 위 가로줄 (초록색)
            cv2.line(frame_with_boxes, (center_x - 60, center_y + 210), (center_x + 40, center_y + 210), (0, 255, 0), 2)  # 아래 가로줄 (초록색)

            #green zone [x: center_x - 60 ~ center_x + 40]
            #green zone [y: center_y + 40 ~ center_y + 210]

            # 바운딩 박스 정보를 가져옴
            boxes = results[0].boxes.xyxy.cpu().numpy()  # 바운딩 박스 좌표 (xmin, ymin, xmax, ymax)

            for i, box in enumerate(boxes):
                xmin, ymin, xmax, ymax = map(int, box)
                box_center_x = int((xmin + xmax) / 2)
                box_center_y = int((ymin + ymax) / 2)

                # 중심점 표시
                cv2.circle(frame_with_boxes, (box_center_x, box_center_y), 5, (0, 0, 255), -1)

                # 중심점 좌표 텍스트 표시
                text = f"({box_center_x}, {box_center_y})"
                cv2.putText(frame_with_boxes, text, (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

                # 로그 출력
                self.get_logger().info(f"Box {i + 1}: Center at ({box_center_x}, {box_center_y})")
                #green zone [x: center_x - 60 ~ center_x + 40]
                #green zone [y: center_y + 40 ~ center_y + 210]
                if center_x - 60 <= box_center_x <= center_x + 40:
                    self.get_logger().warn(f"Box {i + 1}: box_center_x in green zone")
                else: 
                    self.get_logger().error(f"Box {i + 1}: box_center_x in green zone")
                if center_y + 40 <= box_center_y <= center_y + 210:
                    self.get_logger().warn(f"Box {i + 1}: box_center_y not in green zone")
                else: 
                    self.get_logger().error(f"Box {i + 1}: box_center_y not in green zone")
                
            # 탐지된 이미지를 파일로 저장
            filename = "detected_image.jpg"
            cv2.imwrite(filename, frame_with_boxes)
            self.get_logger().info(f"Detected image saved as {filename}")

        # 로그 출력
        self.get_logger().info('Image received and processed.')

def main(args=None):
    rclpy.init(args=args)
    node = ImageSubscriber()
    try:
        rclpy.spin(node)  # 노드 실행
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()  # 노드 삭제
        rclpy.shutdown()  # rclpy 종료

if __name__ == '__main__':
    main()
